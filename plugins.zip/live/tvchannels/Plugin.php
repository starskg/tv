<?php namespace Live\Tvchannels;

use System\Classes\PluginBase;

class Plugin extends PluginBase
{
    public function pluginDetails()
    {
        return [
            'name'        => 'TV Channels',
            'description' => 'Manage TV channels for streaming.',
            'author'      => 'Your Name',
            'icon'        => 'icon-play'
        ];
    }

    public function registerComponents()
    {
        return [
            'Live\Tvchannels\Components\ChannelList' => 'channelList',
            'Live\Tvchannels\Components\ChannelPlayer' => 'channelPlayer'
        ];
    }

    public function registerNavigation()
    {
        return [
            'tvchannels' => [
                'label'       => 'TV Channels',
                'url'         => \Backend::url('live/tvchannels/channels'),
                'icon'        => 'icon-play',
                'permissions' => ['live.tvchannels.*'],
                'order'       => 500,
            ]
        ];
    }
}
