<?php namespace Live\Tvchannels\Components;

use Cms\Classes\ComponentBase;
use Live\Tvchannels\Models\Channel;

class ChannelPlayer extends ComponentBase
{
    public $channel;

    public function componentDetails()
    {
        return [
            'name'        => 'Channel Player',
            'description' => 'Plays the selected channel'
        ];
    }

    public function onRun()
    {
        $this->channel = $this->loadChannel();
    }

    protected function loadChannel()
    {
        $id = $this->property('id');
        return Channel::find($id);
    }

    public function defineProperties()
    {
        return [
            'id' => [
                'title'       => 'Channel ID',
                'description' => 'The ID of the channel to display',
                'default'     => 0,
                'type'        => 'string',
            ]
        ];
    }
}
