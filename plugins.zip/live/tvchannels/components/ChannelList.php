<?php namespace Live\Tvchannels\Components;

use Cms\Classes\ComponentBase;
use Live\Tvchannels\Models\Channel;

class ChannelList extends ComponentBase
{
    public function componentDetails()
    {
        return [
            'name'        => 'Channel List',
            'description' => 'Displays a list of channels'
        ];
    }

    public function onRun()
    {
        $this->page['channels'] = $this->loadChannels();
    }

    protected function loadChannels()
    {
        return Channel::all();
    }
}
