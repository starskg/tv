<?php namespace Live\Tvchannels\Models;

use Model;

class Channel extends Model
{
    public $table = 'channels';

    protected $fillable = ['name', 'stream_url', 'logo', 'description'];
}
