<?php namespace Live\Tvchannels\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class CreateChannelsTable extends Migration
{
    public function up()
    {
        Schema::create('channels', function($table)
        {
            $table->increments('id');
            $table->string('name');
            $table->string('stream_url');
            $table->string('logo')->nullable();
            $table->text('description')->nullable();
        });
    }

    public function down()
    {
        Schema::dropIfExists('channels');
    }
}
