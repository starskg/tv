/// Generated file. Do not edit.

// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars
class AssetsRes {
  static const String PLUGIN_NAME = 'iplive';
  static const String PLUGIN_VERSION = '1.0.0+1';
}