import '../language/english.dart';

late String referCode;
String languageStateName = Strings.english;
late int activeCardIndex;