class AppConfig {
  static const String policyLink =
      'https://doc-hosting.flycricket.io/iplive/f819e391-15d1-402c-8826-24f23d004ab0/privacy';
  static const String aboutUsLink =
      'https://doc-hosting.flycricket.io/about-us/8486717c-206e-4224-b64a-6fc95d76d68c/other';
}