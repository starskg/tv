package net.appdevs.iplive

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
